

hbat <- read.csv("HBAT.csv")  # if you have set the working directory
#hbat <- read.csv("C:\\datasets\\HBAT.csv")  # to use the file's full address


str(hbat)


boxplot(hbat[c(7,8,9,13)])

par(mar=c(5,10,4,2))  # sets an extra-large left margin
boxplot(hbat[c(7,8,9,13)],horizontal=TRUE,ylim=c(0,10),las=1,cex.axis=0.8)


plot(hbat$Website_User_Friendliness,hbat$SF_Image)
plot(hbat$Website_User_Friendliness,hbat$SF_Image,
     main="Scatterplot of Website & Salesforce Perceptions",
     ylab="Salesforce Image", xlab="Website User Friendliness",
     pch=19)


model1 <- lm(hbat$SF_Image~hbat$Website_User_Friendliness)
abline(model1,col="red")
lines(lowess(hbat$Website_User_Friendliness,hbat$SF_Image),col="blue")

plot(hbat$Website_User_Friendliness[hbat$Region==0],
     hbat$SF_Image[hbat$Region==0],
     main="Scatterplot of Website & Salesforce Perceptions",
     ylab="Salesforce Image", xlab="Website User Friendliness",
     ylim=c(2,8),xlim=c(2,6),
     pch=19)
points(hbat$Website_User_Friendliness[hbat$Region==1],
     hbat$SF_Image[hbat$Region==1],
     pch=1,col="red")

lines(lowess(hbat$Website_User_Friendliness[hbat$Region==0],
             hbat$SF_Image[hbat$Region==0]), col="black")
lines(lowess(hbat$Website_User_Friendliness[hbat$Region==1],
             hbat$SF_Image[hbat$Region==1]), col="red")

pairs(hbat[c(7,8,9,13)],cex.labels=1)