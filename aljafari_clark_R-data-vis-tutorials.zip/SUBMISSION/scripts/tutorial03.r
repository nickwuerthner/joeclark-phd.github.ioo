
# get the data
Index<-read.csv("SP500.csv")       
head(Index)
Index <- Index[rev(rownames(index)),]
head(Index)

# create time series object
indexTS<-ts(Index,start=c(2000,1),end=c(2012,12),frequency=12)


# create simple plots
plot(indexTS)
plot(indexTS[,"Close"])

# add trend line
lines( filter(indexTS[,"Close"],rep(1/12,12)), col="red" )

# exponential smoothing
plot(HoltWinters(indexTS[,"Close"]))
plot(HoltWinters(indexTS[,"Close"],alpha=0.4,beta=0.4,gamma=0.4))

# show autocorrelation function
acf(indexTS[,"Close"])
acf(indexTS[,"Close"],lag.max=48)  # shows acf even further out

# decompose
indexDTS <- decompose(indexTS[,"Close"])
plot(indexDTS)

# generate our prediction
HWmodel <- HoltWinters(indexTS[,"Close"])
prediction <- predict(HWmodel,n.ahead=60)

# plot our prediction
plot(indexTS[,"Close"],xlim=c(2000,2018),ylim=c(700,1800))
lines(prediction,col="red")