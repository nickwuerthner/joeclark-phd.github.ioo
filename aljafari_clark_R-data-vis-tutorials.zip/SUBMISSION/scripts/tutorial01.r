

hbat <- read.csv("HBAT.csv")
#hbat <- read.csv("C:\\datasets\\HBAT.csv")  # alternative form


names(hbat)
hbat
head(hbat)
str(hbat)
summary(hbat)


wuf <- hbat$Website_User_Friendliness


length(wuf)  # the number of observations
summary(wuf)
mean(wuf)
median(wuf)
mode(wuf)
quantile(wuf)  # by default, gives quartiles
quantile(wuf,probs=seq(0,1,0.1))  # gives deciles


yvalues <- jitter(rep(1,100))
plot(wuf,yvalues,ylim=c(0.8,1.2),yaxt="n",ylab="")


hist(wuf)
hist(wuf,breaks=seq(2,6,0.1))
stem(wuf)


plot(density(wuf))
plot(density(wuf,bw=0.1))
plot(density(wuf,bw=0.05))


plot(ecdf(wuf))  # ecdf stands for 'empirical CDF'
plot(ecdf(wuf),xaxp=c(2,6,40))  # put 40 tick marks between 2.0 and 6.0
grid()  # add grid lines to the plot


qqnorm(wuf)
qqline(wuf)
?qqplot


