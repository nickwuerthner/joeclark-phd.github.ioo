
imports <- read.csv("imports-85.csv")  # if you have set the working directory
#imports <- read.csv("C:\\datasets\\imports-85.csv")  # to use the file's full address

str(imports)
head(imports)


# clean up 'imports' data set
imports$horsepower <- as.numeric(as.character(imports$horsepower))
imports$highway.mpg <- as.numeric(as.character(imports$highway.mpg))
imports$price <- as.numeric(as.character(imports$price))
levels(imports$num.of.cylinders) <- c(8,5,4,6,3,12,2)
imports$num.of.cylinders <- as.numeric(as.character(imports$num.of.cylinders))
imports <- na.omit(imports)


# interaction plot 1
interaction.plot(imports$num.of.cylinders,  # variable for the x axis
                 imports$price>15000,       # the interaction variable
                 imports$horsepower,        # variable for the y axis
                 mean,                      # how to summarize the data
                 pch=19,type="b",col=c("blue","red"),legend=TRUE)
# interaction plot 2
interaction.plot(imports$num.of.cylinders,  # variable for the x axis
                 imports$price>15000,       # the interaction variable
                 imports$highway.mpg,       # variable for the y axis
                 mean,                      # how to summarize the data
                 pch=19,type="b",col=c("blue","red"),legend=TRUE)


# small multiples

# a minimalist scatterplot
par(mar=c(1,1,2,1))
plot(imports$num.of.cylinders,imports$horsepower,main="cylinders x HP plot", xaxt="n",yaxt="n",xlab="",ylab="",pch=19)

# multi-plot by quartiles
par(mar=c(1,1,2,1))
par(mfrow=c(2,2))
quarts <- quantile(imports$price)
for(q in 1:4) {
  thisquartile <- (imports$price >= quarts[q]) & (imports$price <= quarts[q+1])
  plot(imports[thisquartile,]$num.of.cylinders,
       imports[thisquartile,]$horsepower,
       main=paste("price",quarts[q],"-",quarts[q+1]), 
       xaxt="n",yaxt="n",xlab="",ylab="",pch=19,
       xlim=c(2,12), ylim=c(48,262))
}

# small multiples histogram
par(mfrow=c(5,5))
par(mar=c(1,1,2,1))
for(m in levels(imports$make)) {
  hist(imports[imports$make==m,]$horsepower,
       breaks=seq(25,275,25),
       xaxt="n",yaxt="n",xlab="",ylab="",
       main=m)
}


# generate summary data for 3D plot
makes <- aggregate(imports,by=list(imports$make),FUN=mean)
variables <- c("highway.mpg","horsepower","curb.weight","wheel.base","price")
zdata <- makes[variables]
zdata <- scale(zdata)

#change zdata from data frame to matrix for use in persp() plot
zdata <- as.matrix(zdata)

# do surface plot
persp(1:21,1:5,zdata,
      theta=-40,phi=20,r=5,d=1,  # 3D positioning parameters
      ltheta=-10,lphi=10,shade=1,  # 3D light/shade parameters
      xlab="Make",ylab="Variable",zlab="Value"
      )

# do heatmap
image(1:21,1:5,zdata)

# do a better heatmap
par(mar=c(7,6,2,2))  # make space in margins for axis labels

image(1:21,1:5,zdata,  
      xlab="",ylab="",
      xaxt="n",yaxt="n")

axis(1,at=1:21,labels=makes[,1],las=2,cex.axis=0.8)
axis(2,at=1:5,labels=variables,las=2,cex.axis=0.8)
box()


# use gplots:colorpanel() to specify better colors
install.packages("gplots",dependencies=TRUE) # if you haven't already
library(gplots)
myshades <- colorpanel(256,"white","red")


# do our final heatmap
image(1:21,1:5,zdata,
      col=myshades,
      xlab="",ylab="",
      xaxt="n",yaxt="n")

axis(1,at=1:21,labels=makes[,1],las=2,cex.axis=0.8)
axis(2,at=1:5,labels=variables,las=2,cex.axis=0.8)
box()
