
# If the XML package isn't already installed, use this:
install.packages("XML", dependencies = TRUE)

# load the package:
library(XML)

# get the web page by HTTP request, and parse it:
SP500.doc <- htmlParse("http://finance.yahoo.com/q/hp?s=%5EGSPC&a=00&b=1&c=2008&d=11&e=31&f=2012&g=m")

# get the data in the HTML tables
SP500.tables <- readHTMLTable(SP500.doc)
length(SP500.tables)
head(SP500.tables)
str(SP500.tables)

# find the table we want
str(SP500.tables[[15]])
SP500.tables[[15]]

# grab the data column we want
SP500.close <- SP500.tables[[15]]$Close
SP500.close  # view the dataset

# make the data usable:
SP500.close <- gsub(",","",SP500.close)
SP500.close <- as.numeric(SP500.close)
SP500.close <- SP500.close[1:60]

# save the data:
write.csv(SP500.close,"sp500monthly.csv")
write.csv(SP500.close,"C:\\datasets\\sp500monthly.csv")

# recall the first steps of the time series analysis tutorial
SP500.close <- rev(SP500.close)
SP500.ts <- ts(SP500.close,start=c(2008,1),end=c(2012,12),frequency=12)
plot(SP500.ts)


# generate the "y" values we'll need

# loop to generate and print the URLs we must visit
for(y in y.values) {
  URL <- paste("http://finance.yahoo.com/q/hp",
               "?s=%5EGSPC&a=00&b=1&c=2000&d=11",
               "&e=31&f=2012&g=w&z=679&y=",
               as.character(y),
               sep="")
  print(URL)
}


# loop to capture the real data

SP500weekly = numeric() # an empty numeric vector

for(y in y.values) {
  
  # generate the URL
  URL <- paste("http://finance.yahoo.com/q/hp",
               "?s=%5EGSPC&a=00&b=1&c=2000&d=11",
               "&e=31&f=2012&g=w&z=679&y=",
               as.character(y),
               sep="")

  # get the data from the web, as before
  SP500.doc <- htmlParse(URL)
  SP500.tables <- readHTMLTable(SP500.doc)
  SP500.close <- SP500.tables[[15]]$Close
 
  # clean up the data, as before
  SP500.close <- gsub(",","",SP500.close)
  SP500.close <- as.numeric(SP500.close)
  SP500.close <- SP500.close[1:(length(SP500.close)-1)] # note change
  
  # remove duplicated value in position 1
  if (y>0) { # i.e. if this is not the first "y"
    SP500.close <- SP500.close[2:length(SP500.close)]
  }
  
  # add this page's data to the dataset
  SP500weekly <- append(SP500weekly,SP500.close)
  
}

